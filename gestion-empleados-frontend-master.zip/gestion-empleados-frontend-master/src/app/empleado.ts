export class Empleado{

    id:number;
    nombre:string;
    apellido:string;
    email:string;

}